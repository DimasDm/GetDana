<?php
# config by : muh maulana
# channel : xatoshi lanzz
# telegram : @xatoshilanzz & @cxatoshi

# this script only for country ID
$phone_no = "xxxxx";

?>
